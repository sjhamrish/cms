export class Leftmenu {
    name: string;
    url: string;
    subMenu: Leftmenu[];
}
