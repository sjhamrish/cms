export class User {
    userId: string;
    userName: string;
    password: string;
    firstName: string;
    lastName: string;
    token: string;
    email: string;
    role: string;
}
