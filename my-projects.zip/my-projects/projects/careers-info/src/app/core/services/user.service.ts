import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { Constants } from '../utilities/constants';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get<User[]>(Constants.URL_USERS);
  }

  register(user: User) {
      return this.http.post(Constants.URL_REGISTER, user);
  }

  delete(id: number) {
      return this.http.delete(`/users/${id}`);
  }
}
