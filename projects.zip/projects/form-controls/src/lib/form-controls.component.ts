import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-form-controls',
  template: `
    <p>
      form-controls works!
    </p>
  `,
  styles: [
  ]
})
export class FormControlsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
