import { Component, ViewChild } from '@angular/core';
import { SidebarComponent } from '@syncfusion/ej2-angular-navigations';
import { MasterService } from './core/services/master.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  @ViewChild('sidebar')
  public sidebar: SidebarComponent;
  title = 'cms';

  constructor(
    public masterService: MasterService
    ) { }

  newTabClick(): void {
    let URL = location.href.replace(location.search,'');
    document.getElementById('newTab').setAttribute('href', URL.split('#')[0] + 'sidebar/default');
  }

  toggleClick() {
      this.sidebar.toggle();
  }
  closeClick() {
      this.sidebar.hide();
  }
  openClick() {
      this.sidebar.show();
  }
  //To hide the sidebar element skelton during the page load by setting the visibity style when the control is created.
  onCreated(e: any): void {
      this.sidebar.element.style.visibility = 'visible';
  }
}
