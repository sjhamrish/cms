import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MasterService } from '../../core/services/master.service';
import { MenuService } from '../../core/services/menu.service';
import { Constants } from '../../core/utilities/constants';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit {

  constructor(
    private masterService: MasterService,
    private menuService: MenuService,
    private router: Router
  ) { }

  ngOnInit(): void {
    localStorage.removeItem(Constants.CURRENTUSER);
    this.masterService.isUserLoggedIn = false;
    this.masterService.userInfo = null;
    this.router.navigate([Constants.PG_HOME]);
    this.menuService.getMenu(this.masterService.userInfo ? this.masterService.userInfo.userid : '');
  }

}
