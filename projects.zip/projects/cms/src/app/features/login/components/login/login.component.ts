import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';

import { AuthenticationService } from './../../../../core/services/authentication.service';
import { AlertService } from './../../../../core/services/alert.service';
import { Constants } from './../../../../core/utilities/constants';
import { MasterService } from '../../../../core/services/master.service';
import { MenuService } from '../../../../core/services/menu.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  errorMessage: string = '';
  field = {
    label: 'First Name',
    controlName: 'firstname',
    value: '',
    type: 'text',
    className: '',
    ngClass:'',
    minLength: '',
    maxLength: '',
    required: false,
    pattern: '',
    disabled: false,
    readonly: false,
    size: 16,
    minDate:'',
    maxDate: '',
    fileType: '',
    placeHolder: '',
    step: 0,
    min: 0,
    max: 10,
    width: 0,
    height: 0,
    autocomplete: 'off',
    rows:0,
    columns:0
  };
  form: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private masterService: MasterService,
    private menuService: MenuService
  ) {
        // redirect to home if already logged in
        if (this.authenticationService.currentUserValue) {
          this.router.navigate([Constants.PG_MEET_DASHBOARD]);
      }
   }

  ngOnInit(): void {
    this.form = new FormGroup({});
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }

    this.loading = true;
    this.authenticationService.login(this.f.username.value, this.f.password.value).then(
          data => {
            if(!data) {
              this.masterService.isUserLoggedIn = false;
              this.errorMessage = 'Invalid User name / Password';
            } else {
              this.masterService.isUserLoggedIn = true;
              this.errorMessage = '';

              this.menuService.getMenu(this.masterService.userInfo ? this.masterService.userInfo.userid : '');
              this.router.navigate([Constants.PG_MEET_DASHBOARD]);
            }
            
            this.loading = false;
          },
          error => {
              this.alertService.error(error);
              this.errorMessage = error;
              this.loading = false;
          });
  }

}
