import { MenuModule } from './menu/menu.module';
import { LoginModule } from './login/login.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoutComponent } from './logout/logout.component';



@NgModule({
  declarations: [LogoutComponent],
  imports: [
    CommonModule,
    LoginModule,
    MenuModule
  ]
})
export class FeaturesModule { }
