import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { FeaturesModule } from './features/features.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { fakeSerivceProvider } from './core/utilities/fakeservice.interceptor';
import { SidebarModule } from '@syncfusion/ej2-angular-navigations';
import { GridModule, EditService, ToolbarService, SortService } from '@syncfusion/ej2-angular-grids';
import { DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    CoreModule,
    SharedModule,
    FeaturesModule,
    CommonModule,
    SidebarModule,
    DropDownListModule
  ],
  providers: [fakeSerivceProvider,EditService, ToolbarService, SortService, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
