import { Injectable } from '@angular/core';
import { MenuItemModel } from '@syncfusion/ej2-angular-navigations';
import { Leftmenu } from '../models/leftmenu';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class MasterService {
  public isUserLoggedIn: boolean = false;

  public userInfo: User;

  public topMenu: MenuItemModel[];
  public leftMenu: MenuItemModel[];
    
  constructor() { }
}
