import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { User } from '../models/user';
import { MasterService } from './master.service';
import { Constants } from '../utilities/constants';
import { HttpBase } from '../utilities/httpbase';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  constructor(private http: HttpBase,
    private masterService: MasterService) {
  }

  public get currentUserValue(): any {
    let user = JSON.parse(localStorage.getItem(Constants.CURRENTUSER));

    if(user) {
      this.masterService.userInfo = this.populateUserInfo(user);
    }
    
    return this.masterService.userInfo;
  }

  login(userName: string, password: string) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('userName', userName);
      params = params.set('password', password);
    
      this.http.Post(Constants.URL_AUTHENTICATE, params).subscribe(
        (user: any) => {
          if (user) {
            localStorage.setItem(Constants.CURRENTUSER, JSON.stringify(user));
            this.masterService.userInfo = this.populateUserInfo(user);
            this.masterService.isUserLoggedIn = true;
          }

          resolve(this.masterService.userInfo);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  populateUserInfo(user: any) {
    let userInfo: User = new User();

    userInfo.userid = user.userId;
    userInfo.username = user.userName;
    userInfo.firstname = user.firstName;
    userInfo.lastname = user.lastName;
    userInfo.email = user.email;
    userInfo.role = user.role;
    userInfo.orgid = user.orgId;
    
    return userInfo;
  }
}
