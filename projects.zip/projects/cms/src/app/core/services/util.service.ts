import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Country } from '../models/country';
import { Events } from '../models/events';
import { Eventtype } from '../models/eventtype';
import { Meetlevel } from '../models/meetlevel';
import { Meettype } from '../models/meettype';
import { Organization } from '../models/organization';
import { State } from '../models/state';
import { Constants } from '../utilities/constants';
import { HttpBase } from '../utilities/httpbase';
import { MasterService } from './master.service';

@Injectable({
  providedIn: 'root'
})
export class UtilService {
  
  constructor(private http: HttpBase,
    private masterService: MasterService) { }

  registerOrganization(inputOrg: Organization) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      // params = params.set('userId', this.masterService.userInfo.userId);
      params = params.set('userId', this.masterService.userInfo ? this.masterService.userInfo.userid : '');

      this.http.Post(Constants.URL_REGISTER_ORGANIZATION, params, JSON.stringify(inputOrg)).subscribe(
        (res: any) => {
          resolve;
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  getOrganization() {
    return new Promise((resolve, reject) => {
      let organizations: Organization[] = [];

      this.http.Post(Constants.URL_ORGANIZATION).subscribe(
        (org: any) => {
          if (org) {
            org.forEach(element => {
              let temp: Organization = new Organization();
              temp.orgid = element.orgId;
              temp.orgname = element.orgName;
              temp.addr1 = element.addr1;
              temp.addr2 = element.addr2;
              temp.city = element.city;
              temp.countrycode = element.countrycode;
              temp.description = element.description;
              temp.statecode = element.statecode;
              temp.zip = element.zip;
        
              organizations.push(temp);
            });
          }
          resolve(organizations);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getState(countryId: string) {
    return new Promise((resolve, reject) => {
      let states: State[] = [];
      let params = new HttpParams();
      params = params.set('countryId', countryId);
    
      this.http.Post(Constants.URL_STATE, params).subscribe(
        (state: any) => {
          if (state) {
            state.forEach(element => {
              let temp: State = new State();
              temp.stateid = element.stateId;
              temp.statename = element.stateName;
              temp.statecode = element.stateCode;
        
              states.push(temp);
            });
          }

          resolve(states);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getCountry() {
    return new Promise((resolve, reject) => {
      let countries: Country[] = [];
    
      return this.http.Post(Constants.URL_COUNTRY).subscribe(
        (country: any) => {
          if (country) {
            country.forEach(element => {
              let temp: Country = new Country();
              temp.countryid = element.countryId;
              temp.countryname = element.countryName;
              temp.countrycode = element.countryCode;
        
              countries.push(temp);
            });
          }

          resolve(countries);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getMeetType() {
    return new Promise((resolve, reject) => {
      let meetTypes: Meettype[] = [];
    
      return this.http.Post(Constants.URL_MEET_TYPE).subscribe(
        (type: any) => {
          if (type) {
            type.forEach(element => {
              let temp: Meettype = new Meettype();
              temp.meettypeid = element.meettypeid;
              temp.meettype = element.meettype;
        
              meetTypes.push(temp);
            });
          }

          resolve(meetTypes);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getEventType() {
    return new Promise((resolve, reject) => {
      let eventtypes: Eventtype[] = [];
    
      return this.http.Post(Constants.URL_EVENT_TYPE).subscribe(
        (type: any) => {
          if (type) {
            type.forEach(element => {
              let temp: Eventtype = new Eventtype();
              temp.eventtypeid = element.eventtypeid;
              temp.eventtype = element.eventtype;
        
              eventtypes.push(temp);
            });
          }

          resolve(eventtypes);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getMeetLevel() {
    return new Promise((resolve, reject) => {
      let meetLevels: Meetlevel[] = [];
    
      return this.http.Post(Constants.URL_MEET_LEVEL).subscribe(
        (level: any) => {
          if (level) {
            level.forEach(element => {
              let temp: Meetlevel = new Meetlevel();
              temp.meetlevelid = element.meetlevelid;
              temp.meetlevel = element.meetlevel;
        
              meetLevels.push(temp);
            });
          }

          resolve(meetLevels);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getEvents(eventTypeIds) {
    return new Promise((resolve, reject) => {
      let events: Events[] = [];
      let params = new HttpParams();
      let eventTypeId = '';
      eventTypeIds.forEach(element => {
        eventTypeId += element + ',';
      });
      params = params.set('eventTypeId', eventTypeId);

      return this.http.Post(Constants.URL_EVENTS, params).subscribe(
        (evnts: any) => {
          if (evnts) {
            evnts.forEach(element => {
              let temp: Events = new Events();
              temp.eventid = element.eventId;
              temp.eventname = element.eventName;
              temp.description = element.description;
        
              events.push(temp);
            });
          }

          resolve(events);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }
}
