import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Event } from '@angular/router';
import { Eventplayerscore } from '../models/eventplayerscore';
import { Events } from '../models/events';
import { Meet } from '../models/meet';
import { Meetuser } from '../models/meetuser';
import { Player } from '../models/player';
import { User } from '../models/user';
import { Constants } from '../utilities/constants';
import { HttpBase } from '../utilities/httpbase';
import { MasterService } from './master.service';

@Injectable({
  providedIn: 'root'
})
export class MeetService {

  constructor(private http: HttpBase,
    private masterService: MasterService) { }

  registerMeet(inputMeet: Meet) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('userId', this.masterService.userInfo ? this.masterService.userInfo.userid : '');

      this.http.Post(Constants.URL_REGISTER_MEET, params, JSON.stringify(inputMeet)).subscribe(
        (res: any) => {
          resolve;
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  getMeets() {
    return new Promise((resolve, reject) => {
      let meets: Meet[];

      this.http.Post(Constants.URL_GET_MEETS).subscribe(
        (org: any) => {
          if (org) {
            meets = [];
            org.forEach(element => {
              let temp: Meet = new Meet();
              temp.meetId = element.meetId;
              temp.meetName = element.meetName;
              temp.description = element.description;
              temp.orgId = element.organization;
              temp.meetLevelId = element.meetLevel;
              temp.location = element.location;
              temp.addr1 = element.addr1;
              temp.addr2 = element.addr2;
              temp.city = element.city;
              temp.stateId = element.stateId;
              temp.countryId = element.countryId;
              temp.zip = element.zip;
              temp.startDate = element.startDate;
              temp.endDate = element.endDate;
              temp.age = element.age;
              temp.ageDate = element.ageDate;
              temp.isVerificationNeeded = element.isVerificationNeeded === '' ? false : true;
        
              meets.push(temp);
            });
          }
          resolve(meets);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getAllEventsInMeet(meetId) {
    return new Promise((resolve, reject) => {
      let events: Events[];
      let params = new HttpParams();
      params = params.set('meetId', meetId);

      this.http.Post(Constants.URL_GET_EVENTS_BY_MEET, params).subscribe(
        (evnts: any) => {
          if (evnts) {
            events = [];
            evnts.forEach(element => {
              let temp: Events = new Events();
              temp.eventid = element.eventId;
              temp.eventname = element.eventName;
              temp.meeteventid = element.meetEventId
                      
              events.push(temp);
            });
          }
          resolve(events);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getEvent(meetEventId) {
    return new Promise((resolve, reject) => {
      let event: Events;
      let params = new HttpParams();
      params = params.set('meetEventId', meetEventId);

      this.http.Post(Constants.URL_GET_EVENT, params).subscribe(
        (evnt: any) => {
          if (evnt) {
            evnt = new Events();
            event.eventid = evnt.eventId;
            event.eventname = evnt.eventName;
            event.description = evnt.description;
            event.reportingtime = evnt.reportingTime;
          }

          resolve(event);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getPlayerInfo() {
    return new Promise((resolve, reject) => {
      let player: Player;
      let params = new HttpParams();
      params = params.set('userId', this.masterService.userInfo ? this.masterService.userInfo.userid : '');

      this.http.Post(Constants.URL_GET_PLAYER_INFO, params).subscribe(
        (plyr: any) => {
          if (plyr) {
            player = new Player();
            player.playerid = plyr.playerId;
            player.firstname = plyr.firstName;
            player.lastname = plyr.lastName;
            player.verificationid = plyr.verificationId;
            player.isverified = plyr.isVerified;
            player.dob = plyr.dob;
          }
          resolve(player);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getPlayerList() {
    return new Promise((resolve, reject) => {
      let players: Player[];
      let params = new HttpParams();
      params = params.set('userId', this.masterService.userInfo ? this.masterService.userInfo.userid : '');

      this.http.Post(Constants.URL_GET_PLAYER_LIST, params).subscribe(
        (evnts: any) => {
          if (evnts) {
            players = [];
            evnts.forEach(element => {
              let temp: Player = new Player();
              temp.playerid = element.playerId;
              temp.firstname = element.firstName;
              temp.lastname = element.lastName;
              temp.playername = element.firstName + ' ' + element.lastName;
                      
              players.push(temp);
            });
          }
          resolve(players);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  registerPlayer(inputPlayer: Player) {
    return new Promise((resolve, reject) => {
      
      this.http.Post(Constants.URL_REGISTER_PLAYER, null, JSON.stringify(inputPlayer)).subscribe(
        (res: any) => {
          resolve(res);
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  EnrollPlayer(meetEventId, playerId, lane, reportedTime, score) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('meetEventId', meetEventId);
      params = params.set('playerId', playerId);
      params = params.set('lane', lane);
      params = params.set('reportedTime', reportedTime);
      params = params.set('score', score);
      
      this.http.Post(Constants.URL_ENROLL_PLAYER, params).subscribe(
        (res: any) => {
          resolve(1);
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  UpdateScore(regId, lanes, reportingTimes, scoreIds, scores) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('regId', regId);
      params = params.set('lanes', lanes);
      params = params.set('reportingTimes', reportingTimes);
      params = params.set('scoreIds', scoreIds);
      params = params.set('scores', scores);
      
      this.http.Post(Constants.URL_UPDATE_SCORE, params).subscribe(
        (res: any) => {
          resolve(1);
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  GetMeetInfo(meetId) {
    return new Promise((resolve, reject) => {
      let meet: Meet;
      let params = new HttpParams();
      params = params.set('meetId', meetId);

      this.http.Post(Constants.URL_GET_MEET_INFO, params).subscribe(
        (element: any) => {
          if (element) {
            meet = new Meet();
            meet.meetId = element.meetId;
            meet.meetName = element.meetName;
            meet.description = element.description;
            meet.orgId = element.organization;
            meet.meetLevelId = element.meetLevel;
            meet.location = element.location;
            meet.addr1 = element.addr1;
            meet.addr2 = element.addr2;
            meet.city = element.city;
            meet.stateId = element.stateId;
            meet.countryId = element.countryId;
            meet.zip = element.zip;
            meet.startDate = element.startDate;
            meet.endDate = element.endDate;
            meet.age = element.age;
            meet.ageDate = element.ageDate;
            meet.isVerificationNeeded = element.isVerificationNeeded === '' ? false : true;
          }
          resolve(meet);
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  GetEventById(meetEventId) {
    return new Promise((resolve, reject) => {
      let events: Events;
      let params = new HttpParams();
      params = params.set('meetEventId', meetEventId);
      
      this.http.Post(Constants.URL_GET_EVENT_BY_ID, params).subscribe(
        (element: any) => {
          if (element) {
            events = new Events();
            events.eventid = element.eventId;
            events.eventname = element.eventName;
            events.description = element.description;
            events.scoretypeid = element.scoreTypeId;
            events.eventtypeid = element.eventTypeId;
            events.reportingtime = element.reportingTime;
            events.meeteventid = element.meetEventId;
            events.eventtype = element.eventtype;
            events.lanes = element.lanes;
            events.refid = element.referree?.playerId;
            events.refname = element.referree?.firstName + ' ' + element.referree?.lastName;
          }
          resolve(events);
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  GetEventPlayers(meetEventId) {
    return new Promise((resolve, reject) => {
      let eventScores: Eventplayerscore[];
      let params = new HttpParams();
      params = params.set('meetEventId', meetEventId);
      
      this.http.Post(Constants.URL_GET_EVENT_PLAYERS, params).subscribe(
        (elements: any) => {
          if (elements) {
            eventScores = [];
            elements.forEach(element => {
              let temp: Eventplayerscore = new Eventplayerscore();
              temp.scoreid = element.scoreId;
              temp.playerid = element.player?.playerId;
              temp.playername = element.player?.firstName + ' ' + element.player?.lastName;;
              temp.lane = element.lane;
              temp.score = element.score;
              temp.reportedtime = element.reportedTime;
              temp.registrationid = element.registrationId;
                      
              eventScores.push(temp);
            });
          }
          
          resolve(eventScores);
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  IsPlayerEnrolled(meetEventId, playerId) {
    return new Promise((resolve, reject) => {
      let eventScore: string;
      let params = new HttpParams();
      params = params.set('meetEventId', meetEventId);
      params = params.set('playerId', playerId);
      
      this.http.Post(Constants.URL_IS_PLAYER_ENROLLED, params).subscribe(
        (element: any) => {
          if (element) {
            eventScore = element;
          }
          
          resolve(eventScore);
        },
        error => {
          console.log('oops', error);
          reject();
        }
      );
    });
  }

  updateMeetEvent(inputEvent: Events) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('userId', this.masterService.userInfo ? this.masterService.userInfo.userid : '');

      this.http.Post(Constants.URL_UPDATE_MEET_EVENT, params, JSON.stringify(inputEvent)).subscribe(
        (res: any) => {
          resolve(1);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  getMeetuserList(meetId) {
    return new Promise((resolve, reject) => {
      let users: Meetuser[];
      let params = new HttpParams();
      params = params.set('meetId', meetId);

      this.http.Post(Constants.URL_GET_MEET_USER_LIST, params).subscribe(
        (evnts: any) => {
          if (evnts) {
            users = [];
            evnts.forEach(element => {
              let temp: Meetuser = new Meetuser();
              temp.meetuserid = element.meetUserId;
              temp.username = element.userName;
              temp.firstname = element.firstName;
              temp.lastname = element.lastName;
              temp.password = element.password;
              temp.meetusertypeid = element.meetuserTypeId;
              temp.meetusertype = element.meetuserType;
                      
              users.push(temp);
            });
          }
          resolve(users);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  addMeetUser(inputUsers: Meetuser[]) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('userId', this.masterService.userInfo ? this.masterService.userInfo.userid : '');

      this.http.Post(Constants.URL_ADD_MEET_USER, params, JSON.stringify(inputUsers)).subscribe(
        (res: any) => {
          resolve(1);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  updateMeetUser(inputUsers: Meetuser[]) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('userId', this.masterService.userInfo ? this.masterService.userInfo.userid : '');

      this.http.Post(Constants.URL_UPDATE_MEET_USER, params, JSON.stringify(inputUsers)).subscribe(
        (res: any) => {
          resolve(1);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }

  deleteMeetUser(meetUserIds: string) {
    return new Promise((resolve, reject) => {
      let params = new HttpParams();
      params = params.set('meetUserIds', meetUserIds);

      this.http.Post(Constants.URL_DELETE_MEET_USER, params).subscribe(
        (res: any) => {
          resolve(1);
        },
        error => {
          console.log('oops', error);
          reject(error);
        }
      );
    });
  }
}
