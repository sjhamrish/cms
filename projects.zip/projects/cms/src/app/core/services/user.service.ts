import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { Constants } from '../utilities/constants';
import { HttpBase } from '../utilities/httpbase';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpBase) { }

  getAll() {
    return this.http.Get(Constants.URL_USERS);
  }

  register(user: User) {
      return this.http.Post(Constants.URL_REGISTER, null, JSON.stringify(user));
  }

  updateUser(user: User) {
    return this.http.Post(Constants.URL_UPDATE_USER, null, JSON.stringify(user));
}
}
