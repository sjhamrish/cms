import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MenuItemModel } from '@syncfusion/ej2-angular-navigations';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Leftmenu } from '../models/leftmenu';
import { Topmenu } from '../models/topmenu';
import { Constants } from '../utilities/constants';
import { HttpBase } from '../utilities/httpbase';
import { MasterService } from './master.service';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private subject = new Subject<any>();

  constructor(private http: HttpBase,
    private masterService: MasterService) {

  }

  updateMenu() {
    this.subject.next();
  }

  observeMenu(): Observable<any> {
    return this.subject.asObservable();
  } 

  public get getLeftMenu(): MenuItemModel[] {
    return this.masterService.leftMenu;
  }

  getMenu(userId: string) {
    // Initialize Params Object
    let params = new HttpParams();

    // Begin assigning parameters
    params = params.append('inputUserId', userId);
    
    return this.http.Post(Constants.URL_MENU, params).subscribe(
      (menu: any) => {
        if (menu) {
          this.masterService.topMenu = this.populateTopMenu(menu.topMenu);
          this.masterService.leftMenu = this.populateLeftMenu(menu.leftMenu);
          this.updateMenu();
        }
      },
      error => console.log('oops', error)
    );
  }

  populateTopMenu(menu: any) {
    let topMenu: Topmenu[] = [];
    menu.forEach(element => {
      let temp: Topmenu = new Topmenu();
      temp.text = element.name;
      temp.url = element.url;

      if(element.subMenu) {
        temp.items = [];
        element.subMenu.forEach(sub => {
          let subMenu: Topmenu = new Topmenu();
          subMenu.text = sub.name;
          subMenu.url = sub.url;
          temp.items.push(subMenu);
        });
      }

      topMenu.push(temp);

      if(element.name === 'Home') {
        if (this.masterService.isUserLoggedIn) {
          let temp: Topmenu = new Topmenu();
          temp.text = "Dashboard";
          temp.url = "/meetdashboard";
          topMenu.push(temp);
        }
      }
    });

    if (this.masterService.isUserLoggedIn) {
      let temp: Topmenu = new Topmenu();
      temp.text = "Logout";
      temp.url = "/logout";
      topMenu.push(temp);
    } else {
      let temp: Topmenu = new Topmenu();
      temp.text = "Login";
      temp.url = "/login";
      topMenu.push(temp);
    }

    return topMenu;
  }

  populateLeftMenu(menu: any) {
    let leftMenu: MenuItemModel[] = [];
    menu.forEach(element => {
      let temp: MenuItemModel = {
        text: element.name,
        url: element.url,
        items: []
      }

      if(element.subMenu) {
        element.subMenu.forEach(sub => {
          let subMenu: MenuItemModel = {
            text: sub.name,
            url: sub.url
          }
          
          temp.items.push(subMenu);
        });
      }

      leftMenu.push(temp);
    });

    return leftMenu;
  }
}
