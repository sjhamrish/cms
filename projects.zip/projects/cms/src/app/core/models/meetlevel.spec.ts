import { Meetlevel } from './meetlevel';

describe('Meetlevel', () => {
  it('should create an instance', () => {
    expect(new Meetlevel()).toBeTruthy();
  });
});
