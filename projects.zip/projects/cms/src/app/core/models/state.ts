export class State {
stateid: string;
statename: string;
statecode: string;
createdby: string;
createdate: string;
updatedby: string;
updatedate: string;
}
