export class Meettype {
    meettypeid: string;
    meettype: string;
    isselected: boolean;
    createdby: string;
    createdate: string;
    updatedby: string;
    updatedate: string;
}
