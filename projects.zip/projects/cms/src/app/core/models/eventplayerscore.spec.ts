import { Eventplayerscore } from './eventplayerscore';

describe('Eventplayerscore', () => {
  it('should create an instance', () => {
    expect(new Eventplayerscore()).toBeTruthy();
  });
});
