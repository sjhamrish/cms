import { Meet } from './meet';

describe('Meet', () => {
  it('should create an instance', () => {
    expect(new Meet()).toBeTruthy();
  });
});
