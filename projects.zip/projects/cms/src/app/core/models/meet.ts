export class Meet {
    meetId: string;
    meetName: string;
    description: string;
    orgId: string;
    meetLevelId: string;
    location: string;
    addr1: string;
    addr2: string;
    city: string;
    stateId: string;
    countryId: string;
    zip: string;
    startDate: string;
    endDate: string;
    age: string;
    ageDate: string;
    isPublic: string;
    isVerificationNeeded: boolean;
    createdBy: string;
    createDate: string;
    updatedBy: string;
    updateDate: string;
    reportingTime: string;
    eventIds: string;
}
