export class Organization {
    orgid: string;
    orgname: string;
    description: string;
    addr1: string;
    addr2: string;
    city: string;
    statecode: string;
    countrycode: string;
    zip: string;
    createdby: string;
    createdate: string;
    updatedby: string;
    updatedate: string;
}
