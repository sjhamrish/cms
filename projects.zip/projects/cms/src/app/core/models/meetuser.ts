export class Meetuser {
    meetuserid: number;
    username: string;
    firstname: string;
    lastname: string;
    password: string;
    meetusertypeid: number;
    meetusertype: string;
    meetid: number;
}
