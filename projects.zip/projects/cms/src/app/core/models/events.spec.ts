import { Events } from './events';

describe('Events', () => {
  it('should create an instance', () => {
    expect(new Events()).toBeTruthy();
  });
});
