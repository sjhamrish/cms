import { Meetuser } from './meetuser';

describe('Meetuser', () => {
  it('should create an instance', () => {
    expect(new Meetuser()).toBeTruthy();
  });
});
