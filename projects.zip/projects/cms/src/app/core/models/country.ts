export class Country {
    countryid: string;
    countryname: string;
    countrycode: string;
    createdby: string;
    createdate: string;
    updatedby: string;
    updatedate: string;
}
