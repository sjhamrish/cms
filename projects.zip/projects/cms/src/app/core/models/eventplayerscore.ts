export class Eventplayerscore {
    registrationid: string;
    scoreid: string;
    playerid: string;
    playername: string;
    lane: string;
    score: string;
    reportedtime: string;
}
