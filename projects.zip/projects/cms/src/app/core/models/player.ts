export class Player {
    playerid: number;
    playername: string;
    firstname: string;
    lastname: string;
    verificationid: string;
    isverified: boolean;
    dob: string;
    playertypeid: number;
    playertype: string;
}
