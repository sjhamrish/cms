import { Eventtype } from './eventtype';

describe('Eventtype', () => {
  it('should create an instance', () => {
    expect(new Eventtype()).toBeTruthy();
  });
});
