import { Meettype } from './meettype';

describe('Meettype', () => {
  it('should create an instance', () => {
    expect(new Meettype()).toBeTruthy();
  });
});
