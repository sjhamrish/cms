import { Player } from "./player";

export class Events {
    eventid: string;
    eventname: string;
    description: string;
    scoretypeid: string;
    eventtypeid: string;
    reportingtime: string;
    meeteventid: string;
    eventtype: string;
    lanes: string;
    referree: Player;
    refid: number;
    refname: string;
    isselected: boolean;
    createdby: string;
    createdate: string;
    updatedby: string;
    updatedate: string;
}
