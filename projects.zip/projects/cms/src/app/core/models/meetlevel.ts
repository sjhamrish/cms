export class Meetlevel {
    meetlevelid: string;
    meetlevel: string;
    isselected: boolean;
    createdby: string;
    createdate: string;
    updatedby: string;
    updatedate: string;
}
