export class User {
    userid: string;
    username: string;
    password: string;
    fullname: string;
    firstname: string;
    lastname: string;
    token: string;
    email: string;
    role: string;
    orgid: string;
}
