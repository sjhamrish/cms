export class Topmenu {
    text: string;
    url: string;
    items: Topmenu[];
}
