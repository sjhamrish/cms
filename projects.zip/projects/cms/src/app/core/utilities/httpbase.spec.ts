import { Httpbase } from './httpbase';

describe('Httpbase', () => {
  it('should create an instance', () => {
    expect(new Httpbase()).toBeTruthy();
  });
});
