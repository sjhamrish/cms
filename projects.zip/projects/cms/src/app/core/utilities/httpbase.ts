import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "../../../environments/environment";
import { Constants } from "./constants";

@Injectable({
    providedIn: 'root'
  })
export class HttpBase {
    constructor(private http: HttpClient) { }

    public Get(api: string, params?: any) {
        return this.http.get(environment.apiurl + api, params);
    }

    public Post(api: string, params?: any, body?: any) {
        var headers = new HttpHeaders({
            "Content-Type": "application/json",
            "Accept": "application/json"
        });

        if(body && body !== '' && params) {
            return this.http.post(environment.apiurl + api, body, {headers: headers, params: params});
        } else if ((!body || body === '') && params) {
            return this.http.post(environment.apiurl + api, null, {headers: headers, params: params});            
        } else if (body && body !== '' && !params) {
            return this.http.post(environment.apiurl + api, body, {headers: headers});
        } else {
            return this.http.post(environment.apiurl + api, null, {headers: headers});
        }
        
    }
}
