export abstract class Constants {
    // API urls 
    static readonly URL_MENU = '/menu/getMenu';
    
    static readonly URL_AUTHENTICATE = '/user/login';
    static readonly URL_REGISTER = '/user/register';
    static readonly URL_UPDATE_USER = '/user/updateuser';
    static readonly URL_USERS = '/users';
    
    static readonly URL_ORGANIZATION = '/util/getorganization';
    static readonly URL_STATE = '/util/getstate';
    static readonly URL_COUNTRY = '/util/getcountry';
    static readonly URL_MEET_TYPE = '/util/getmeettype';
    static readonly URL_EVENT_TYPE = '/util/geteventtype';
    static readonly URL_MEET_LEVEL = '/util/getmeetlevel';
    static readonly URL_EVENTS = '/util/getevents';
    static readonly URL_REGISTER_ORGANIZATION = '/util/registerorganization';
    
    static readonly URL_REGISTER_MEET = '/meet/registermeet';
    static readonly URL_GET_MEETS = '/meet/getmeets';
    static readonly URL_GET_EVENTS_BY_MEET = '/meet/getalleventsinmeet';
    static readonly URL_GET_EVENT = '/meet/getevent';
    static readonly URL_GET_PLAYER_INFO = '/meet/getplayerinfo';
    static readonly URL_REGISTER_PLAYER = '/meet/registerplayer';
    static readonly URL_ENROLL_PLAYER = '/meet/enrollplayer';

    static readonly URL_GET_MEET_INFO = '/meet/getmeetinfo';
    static readonly URL_GET_EVENT_BY_ID = '/meet/geteventbyid';
    static readonly URL_GET_EVENT_PLAYERS = '/meet/geteventplayers';
    static readonly URL_GET_PLAYER_LIST = '/meet/getplayerlist';
    static readonly URL_GET_MEET_USER_LIST = '/meet/getmeetuserlist';

    static readonly URL_IS_PLAYER_ENROLLED = '/meet/isplayerenrolled';
    static readonly URL_UPDATE_MEET_EVENT = '/meet/updatemeetevent';
    static readonly URL_UPDATE_SCORE = '/meet/updatescore';

    static readonly URL_ADD_MEET_USER = '/meet/addmeetuser';
    static readonly URL_UPDATE_MEET_USER = '/meet/updatemeetuser';
    static readonly URL_DELETE_MEET_USER = '/meet/deletemeetuser';
    
    //PAGES 
    static readonly PG_ACCOUNTHOME = '/accounthome';
    static readonly PG_HOME = '/home';
    static readonly PG_LOGIN = '/login';
    static readonly PG_REGISTER = '/register';
    static readonly PG_DASHBOARD = '/dashboard';
    static readonly PG_MEET_DASHBOARD = '/meetdashboard';
    static readonly PG_HOMEACCOUNT = '/myaccount';
    static readonly PG_REGISTER_MEET = '/registermeet';
    static readonly PG_MEET_USER = '/meetuser';

    static readonly PG_MEET_SCORE = '/scoring';
    static readonly PG_MEET_SETUP = '/meetsetup';

    // string
    static readonly CURRENTUSER = 'currentUser';

    // roles
    static readonly USER = '1';
    static readonly ADMIN = '2';
    static readonly SUPER = '3';
}
