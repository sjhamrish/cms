import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Events } from '../../models/events';
import {Meet} from '../../models/meet';
import { MeetService } from '../../services/meet.service';
import { EditSettingsModel, GridComponent, ToolbarItems } from '@syncfusion/ej2-angular-grids';
import { Player } from '../../models/player';
import { Eventplayerscore } from '../../models/eventplayerscore';
import { Constants } from '../../utilities/constants';

import { MouseEventArgs } from '@syncfusion/ej2-base';

@Component({
  selector: 'app-meetscoring',
  templateUrl: './meetscoring.component.html',
  styleUrls: ['./meetscoring.component.scss']
})
export class MeetscoringComponent implements OnInit {
  @ViewChild('grid') 
  public grid: GridComponent;
  
  meetId: string;
  meetEventId: string;
  eventMeetData: object;
  
  meetData:Meet[];
  eventplayers: Eventplayerscore[];

  evntData: Events[];
  public evntFields: Object = { text: 'eventname', value: 'meeteventid' };
  public meetFields:Object = {text:'meetName',value:'meetId' };
  
  public meetIdValue : number = 0;
  public meetEventIdValue : number = 0;
  
  playerData: Player[];
  playerFields: Object = {text:'playername',value:'playerid' };
  
  public editSettings: EditSettingsModel;
  public toolbar: ToolbarItems[];  
  
  constructor(private meetService: MeetService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.meetId = this.route.snapshot.paramMap.get('meetid');
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Batch' };
    this.toolbar =  ['Delete', 'Update', 'Cancel'];
    this.meetService.getMeets().then((res:any)=>{
      this.meetData = res;
    });
    this.meetId = this.route.snapshot.paramMap.get('meetid');

    if(this.meetId) {
      this.meetIdValue = Number(this.meetId);

      this.meetService.getAllEventsInMeet(this.meetId).then((res: any) => {
        if(res) {
          this.evntData = res;

          this.meetEventId = this.route.snapshot.paramMap.get('meeteventid');
          if(this.meetEventId) {
            this.meetEventIdValue = Number(this.meetEventId);

            this.meetService.GetEventPlayers(this.meetEventId).then((res: any) => {
              if(res) {
                this.eventplayers = res;
              } else {
                this.eventplayers = [];
              }
            });
          }
        }
      })
    }
  }

  onBackClick() {
    if (this.meetId) {
      this.router.navigate([Constants.PG_MEET_SETUP, {meetid: this.meetId}]);
    } else {
      // TODO Alert
    }
  }

  eventChangeEvent(e : any) {
    this.meetEventId = e.value;
    this.meetService.GetEventPlayers(e.value).then((res: any) => {
      if(res) {
        this.eventplayers = res;
      } else {
        this.eventplayers = [];
      }
    });
  }

  public beforeBatchSave(e: any): void {
    e.cancel = true;         
    let data = { 
        action: 'batch', Changed: e.batchChanges.changedRecords, Deleted: e.batchChanges.deletedRecords 
    }
    
    let regId: string = '';
    let lanes: string = '';
    let reportingTimes: string = '';
    let scoreIds: string = '';
    let scores: string = '';

    data.Changed.forEach(element => {
      if(regId === '') {
        regId = element.registrationid;
      } else {
        regId += ',' + element.registrationid;
      }

      if(lanes === '') {
        lanes = element.lane;
      } else {
        lanes += ',' + element.lane;
      }

      if(reportingTimes === '') {
        reportingTimes = element.reportedtime === '' ? '0' : element.reportedtime;
      } else {
        reportingTimes += ',' + (element.reportedtime === '' ? '0' : element.reportedtime);
      }

      if(scoreIds === '') {
        scoreIds = element.scoreid;
      } else {
        scoreIds += ',' + element.scoreid;
      }

      if(scores === '') {
        scores = element.score;
      } else {
        scores += ',' + element.score;
      }
    });

    this.meetService.UpdateScore(regId, lanes, reportingTimes, scoreIds, scores).then(res => {
      this.meetService.GetEventPlayers(this.meetEventId).then((res: any) => {
        if(res) {
          this.eventplayers = res;
          this.grid.refresh();
        } else {
          this.eventplayers = [];
        }
      });
    });
  }

  load(args){
    this.grid.element.addEventListener('mousedown', (e: MouseEventArgs) => {
      if ((e.target as HTMLElement).classList.contains("e-rowcell")) {
        let index: number = parseInt((e.target as HTMLElement).getAttribute("Index"));
        let colindex: number = parseInt((e.target as HTMLElement).getAttribute("aria-colindex"));
        let field: string = this.grid.getColumns()[colindex].field;
        this.grid.editModule.editCell(index, field);
      };
    });
  }
}
