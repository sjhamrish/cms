import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TextBoxComponent } from '@syncfusion/ej2-angular-inputs';
import { Country } from '../../models/country';
import { Events } from '../../models/events';
import { Eventtype } from '../../models/eventtype';
import { Meet } from '../../models/meet';
import { Meetlevel } from '../../models/meetlevel';
import { Meettype } from '../../models/meettype';
import { Organization } from '../../models/organization';
import { State } from '../../models/state';
import { MeetService } from '../../services/meet.service';
import { UtilService } from '../../services/util.service';

import { FilteringEventArgs } from '@syncfusion/ej2-dropdowns';
import { EmitType } from '@syncfusion/ej2-base';
import { Query } from '@syncfusion/ej2-data';

@Component({
  selector: 'app-registermeet',
  templateUrl: './registermeet.component.html',
  styleUrls: ['./registermeet.component.scss']
})
export class RegistermeetComponent implements OnInit {
  @ViewChild('default')
  public textareaObj: TextBoxComponent;
  registerMeetForm: FormGroup;
  loading = false;
  submitted = false;

  public orgData: Organization[];
  public orgFields: Object = { text: 'orgname', value: 'orgid' };

  public stateData: State[];
  public stateFields: Object = { text: 'statename', value: 'stateid' };
  
  // public ctryData: Country[];
  public ctryData: { [key: string]: Object }[];
  public ctryFields: Object = { text: 'countryname', value: 'countryid' };

  public mtLvlData: Meetlevel[];
  public mtTypeData: Meettype[];
  public evtTypeData: Eventtype[];
  public eventData: Events[];
  
  public eventTypeIds: string[] = [];

  public startDateValue: Date;
  public endDateValue: Date;
  public ageDateValue: Date;

   

    public text: string = "Select a country";

    


  meetId: string;
  meetInfo: Meet;

  constructor(private formBuilder: FormBuilder,
    private utilService: UtilService,
    private meetService: MeetService,
    private route: ActivatedRoute) { 
    
    }

  ngOnInit(): void {
    this.registerMeetForm = this.formBuilder.group({
      meetname: ['', Validators.required],
      description: [''],
      organization: ['', Validators.required],
      location: ['', Validators.required],
      addr1: [''],
      addr2: [''],
      city: [''],
      state: [''],
      country: [''],
      zip: [''],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      age: [''],
      ageDate: [''],
      isVerificationNeeded: [''],
      isMeetPublic: [''],
      meetType: ['', Validators.required],
      meetLevel: ['', Validators.required],
      eventType: ['', Validators.required],
      event: ['', Validators.required]
    });

    this.utilService.getOrganization().then((res: any) => {
      if(res) {
        this.orgData = res;
      }
    });

    this.utilService.getCountry().then((res: any) => {
      if(res) {
        this.ctryData = res;
      }
    });

    this.utilService.getMeetLevel().then((res: any) => {
      if(res) {
        this.mtLvlData = res;
      }
    });

    this.utilService.getMeetType().then((res: any) => {
      if(res) {
        this.mtTypeData = res;
      }
    });

    this.utilService.getEventType().then((res: any) => {
      if(res) {
        this.evtTypeData = res;
      }
    });

    this.meetId = this.route.snapshot.paramMap.get('meetid');

    if(this.meetId) {
      this.meetService.GetMeetInfo(this.meetId).then((res: any) => {
        if (res) {
          this.meetInfo = res;
  
          this.f.meetname.setValue(this.meetInfo.meetName);
          this.f.description.setValue(this.meetInfo.description);
          this.f.organization.setValue(this.meetInfo.orgId);
          this.f.location.setValue(this.meetInfo.location);
          this.f.addr1.setValue(this.meetInfo.addr1);
          this.f.addr2.setValue(this.meetInfo.addr2);
          this.f.city.setValue(this.meetInfo.city);
          this.f.state.setValue(this.meetInfo.stateId);
          this.f.country.setValue(this.meetInfo.countryId);
          this.f.zip.setValue(this.meetInfo.zip);
          this.f.startDate.setValue(this.meetInfo.startDate);
          this.f.endDate.setValue(this.meetInfo.endDate);
          this.f.age.setValue(this.meetInfo.age);
          this.f.ageDate.setValue(this.meetInfo.ageDate);
          this.f.isVerificationNeeded.setValue(this.meetInfo.isVerificationNeeded);
          this.f.isMeetPublic.setValue(this.meetInfo.isPublic);
          this.f.meetLevel.setValue(this.meetInfo.meetLevelId);
          // this.f.eventType.setValue(this.meetInfo.e);
          // this.f.event.setValue(this.meetInfo.);
        }
      })
    }
  }

 



  get f() { return this.registerMeetForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerMeetForm.invalid) {
        return;
    }

    let inputMeet = new Meet();
    inputMeet.meetName = this.f.meetname.value;
    inputMeet.description = this.f.description.value;
    inputMeet.orgId = this.f.organization.value;
    inputMeet.meetLevelId = this.f.meetLevel.value;
    inputMeet.location = this.f.location.value;
    inputMeet.addr1 = this.f.addr1.value;
    inputMeet.addr2 = this.f.addr2.value;
    inputMeet.city = this.f.city.value;
    inputMeet.stateId = this.f.state.value;
    inputMeet.countryId = this.f.country.value;
    inputMeet.zip = this.f.zip.value;
    inputMeet.startDate = this.f.startDate.value;
    inputMeet.endDate = this.f.endDate.value;
    inputMeet.age = this.f.age.value;
    inputMeet.ageDate = this.f.ageDate.value;
    inputMeet.isVerificationNeeded = this.f.isVerificationNeeded.value === '' ? false : true;

    let eventTypeId = '';
    this.eventTypeIds.forEach(element => {
      eventTypeId += element + ',';
    });
    inputMeet.eventIds = eventTypeId;

    // this.loading = true;
    this.meetService.registerMeet(inputMeet);
  }

  public createHandler(e): void {
    this.textareaObj.addAttributes({rows: '1'});
    this.textareaObj.element.style.height = "auto";
    this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }

  public inputHandler(e): void {
    this.textareaObj.element.style.height = "auto";
    this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }
  public onFilteringCountry: EmitType<any> =  (e: FilteringEventArgs) => {
    let query = new Query();
    //frame the query based on search string with filter type.
    query = (e.text != "") ? query.where("countryname", "startswith", e.text, true) : query;
    //pass the filter data source, filter query to updateData method.
    e.updateData(this.ctryData, query);
};
  crtyChangeEvent(e : any) {
    this.utilService.getState(e.value).then((res: any) => {
      if(res) {
        this.stateData = res;
      } else {
        this.stateData = [];
      }
    });
  }
  

  changeEventType(e: any, eventTypeId) {
    if (e.checked) {
      this.eventTypeIds.push(eventTypeId);
    } else {
        this.eventTypeIds.splice(this.eventTypeIds.indexOf(eventTypeId), 1);
    }
    
    this.utilService.getEvents(this.eventTypeIds).then((res: any) => {
      if(res) {
        this.eventData = res;
      } else {
        this.eventData = [];
      }
    });
  }
}
