import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistermeetComponent } from './registermeet.component';

describe('RegistermeetComponent', () => {
  let component: RegistermeetComponent;
  let fixture: ComponentFixture<RegistermeetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistermeetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistermeetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
