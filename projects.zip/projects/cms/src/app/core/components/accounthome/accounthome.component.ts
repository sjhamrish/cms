import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DropDownListComponent } from '@syncfusion/ej2-angular-dropdowns';
import { SidebarComponent } from '@syncfusion/ej2-angular-navigations';
import { Organization } from '../../models/organization';
import { User } from '../../models/user';
import { AuthenticationService } from '../../services/authentication.service';
import { MasterService } from '../../services/master.service';
import { UserService } from '../../services/user.service';
import { UtilService } from '../../services/util.service';

@Component({
  selector: 'app-accounthome',
  templateUrl: './accounthome.component.html',
  styleUrls: ['./accounthome.component.scss']
})
export class AccounthomeComponent implements OnInit {
  @ViewChild('org')
  public orgListObject: DropDownListComponent;
  userForm: FormGroup;

  loading = false;
  submitted = false;
  
  userInfo: User;

  public orgData: Organization[];
  public orgFields: Object = { text: 'orgname', value: 'orgid' };

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    public masterService: MasterService,
    private utilService: UtilService,
    private authenticationService: AuthenticationService,
    private userService: UserService) { }

  ngOnInit(): void {
    this.userForm = this.formBuilder.group({
      firstName: [''],
      lastName: [''],
      email: ['', [Validators.required, Validators.email]],
      userName: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      organization: ['']
    });

    this.userInfo = this.authenticationService.currentUserValue;
    if (this.userInfo) {
      this.f.firstName.setValue(this.userInfo.firstname);
      this.f.lastName.setValue(this.userInfo.lastname);
      this.f.email.setValue(this.userInfo.email);
      this.f.userName.setValue(this.userInfo.username);
      this.f.password.setValue(this.userInfo.password);
      if(this.userInfo.orgid) {
        this.f.organization.setValue(Number(this.userInfo.orgid));
      }
    }

    this.utilService.getOrganization().then((res: any) => {
      if(res) {
        this.orgData = res;
      }
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.userForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.userForm.invalid) {
      return;
    }

    let inputUser = new User();
    inputUser.firstname = this.f.firstName.value;
    inputUser.lastname = this.f.lastName.value;
    inputUser.email = this.f.email.value;
    inputUser.username = this.f.userName.value;
    inputUser.password = this.f.password.value;
    inputUser.orgid = this.f.organization.value;

    this.loading = true;
    this.userService.updateUser(inputUser);
  }

  onCancelClick() {
    this.router.navigate(['/meetdashboard']);
  }
}
