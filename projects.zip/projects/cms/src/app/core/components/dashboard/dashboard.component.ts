import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public data: object[] = [
    {
        meetid: 1, meetname: 'Meet 1', startdate: new Date(8364186e5), enddate: new Date(8364186e5)
    },
    {
        meetid: 2, meetname: 'Meet 2', startdate: new Date(8364186e5), enddate: new Date(8364186e5)
    },
    {
        meetid: 3, meetname: 'Meet 3', startdate: new Date(8364186e5), enddate: new Date(8364186e5)
    },
    {
        meetid: 4, meetname: 'Meet 4', startdate: new Date(8364186e5), enddate: new Date(8364186e5)
    }];

  constructor() { }

  ngOnInit(): void {
  }

}
