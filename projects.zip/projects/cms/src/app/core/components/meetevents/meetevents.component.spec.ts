import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeeteventsComponent } from './meetevents.component';

describe('MeeteventsComponent', () => {
  let component: MeeteventsComponent;
  let fixture: ComponentFixture<MeeteventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeeteventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeeteventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
