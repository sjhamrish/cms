import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-meetevents',
  templateUrl: './meetevents.component.html',
  styleUrls: ['./meetevents.component.scss']
})
export class MeeteventsComponent implements OnInit {
  public display: string;
  public data: object[] = [
    {
        meeteventid: 1, eventname: 'event 1', status: 'scored'
    },
    {
        meeteventid: 2, eventname: 'event 2', status: 'scored'
    },
    {
        meeteventid: 3, eventname: 'event 3', status: 'scored'
    },
    {
        meeteventid: 4, eventname: 'event 4', status: 'scored'
    }];

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.display = this.route.snapshot.paramMap.get('meetid');
  }

}
