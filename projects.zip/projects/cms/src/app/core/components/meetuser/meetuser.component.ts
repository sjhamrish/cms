import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EditSettingsModel, GridComponent, ToolbarItems } from '@syncfusion/ej2-angular-grids';
import { Meet } from '../../models/meet';
import { Meetuser } from '../../models/meetuser';
import { MeetService } from '../../services/meet.service';
import { MouseEventArgs } from '@syncfusion/ej2-base';
import { Constants } from '../../utilities/constants';

@Component({
  selector: 'app-meetuser',
  templateUrl: './meetuser.component.html',
  styleUrls: ['./meetuser.component.scss']
})
export class MeetuserComponent implements OnInit {
  @ViewChild('grid') 
  public grid: GridComponent;

  meetId: string;
  meetIdValue : number = 0;
  meetusers: Meetuser[];

  meetData:Meet[];
  public meetFields:Object = {text:'meetName', value:'meetId' };

  public editSettings: EditSettingsModel;
  public toolbar: ToolbarItems[];  
  
  constructor(private meetService: MeetService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.meetId = this.route.snapshot.paramMap.get('meetid');
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Batch' };
    this.toolbar =  ['Add', 'Delete', 'Update', 'Cancel'];
    this.meetService.getMeets().then((res:any)=>{
      this.meetData = res;
    });

    if(this.meetId) {
      this.getMeetuserList();
    }
  }

  getMeetuserList() {
    this.meetService.getMeetuserList(this.meetId).then((res: any) => {
      if(res) {
        this.meetusers = res;
      }
    })
  }

  onBackClick() {
    if (this.meetId) {
      this.router.navigate([Constants.PG_MEET_SETUP, {meetid: this.meetId}]);
    } else {
      // TODO Alert
    }
  }

  public beforeBatchSave(e: any): void {
    e.cancel = true;         
    let data = { 
        action: 'batch', Added: e.batchChanges.addedRecords, Changed: e.batchChanges.changedRecords, Deleted: e.batchChanges.deletedRecords 
    }
    
    if(data.Added.length > 0) {
      let users: Meetuser[] = [];

      data.Added.forEach(element => {
        let temp: Meetuser = new Meetuser();
        temp.username = element.username;
        temp.firstname = element.firstname;
        temp.lastname = element.lastName;
        temp.password = element.password;
        temp.meetusertype = element.meetusertype;
        temp.meetid = Number(this.meetId);
                
        users.push(temp);
      });

      this.meetService.addMeetUser(users).then(res => {
        if(res) {
          this.getMeetuserList();
        }
      });
    }

    if(data.Changed.length > 0) {
      let users: Meetuser[] = [];

      data.Changed.forEach(element => {
        let temp: Meetuser = new Meetuser();
        temp.meetuserid = element.meetuserid;
        temp.username = element.username;
        temp.firstname = element.firstname;
        temp.lastname = element.lastName;
        temp.password = element.password;
        temp.meetusertype = element.meetusertype;
                
        users.push(temp);
      });

      this.meetService.updateMeetUser(users).then(res => {
        if(res) {
          this.getMeetuserList();
        }
      });
    }
    
    if(data.Deleted.length > 0) {
      let meetUserIds: string = '';
    
      data.Deleted.forEach(element => {
        if(meetUserIds === '') {
          meetUserIds = element.meetuserid;
        } else {
          meetUserIds += ',' + element.meetuserid;
        }
      });
  
      this.meetService.deleteMeetUser(meetUserIds).then(res => {
        if(res) {
          this.getMeetuserList();
        }
      });
    }
  }

  load(args){
    this.grid.element.addEventListener('mousedown', (e: MouseEventArgs) => {
      if ((e.target as HTMLElement).classList.contains("e-rowcell")) {
        let index: number = parseInt((e.target as HTMLElement).getAttribute("Index"));
        let colindex: number = parseInt((e.target as HTMLElement).getAttribute("aria-colindex"));
        let field: string = this.grid.getColumns()[colindex].field;
        this.grid.editModule.editCell(index, field);
      };
    });
  }
}
