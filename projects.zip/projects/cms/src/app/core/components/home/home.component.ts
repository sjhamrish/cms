import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { MasterService } from '../../services/master.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  data: string;
  constructor(private authenticationService: AuthenticationService,
    private masterService: MasterService) { }

  ngOnInit(): void {
    const currentUser = this.authenticationService.currentUserValue;
    if (currentUser) {
      this.masterService.isUserLoggedIn = true;
    } else {
      this.masterService.isUserLoggedIn = false;
    }
  }

}
