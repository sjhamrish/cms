import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TextBoxComponent } from '@syncfusion/ej2-angular-inputs';
import { Country } from '../../models/country';
import { Organization } from '../../models/organization';
import { State } from '../../models/state';
import { UtilService } from '../../services/util.service';
import { Constants } from '../../utilities/constants';

@Component({
  selector: 'app-registerorganization',
  templateUrl: './registerorganization.component.html',
  styleUrls: ['./registerorganization.component.scss']
})
export class RegisterorganizationComponent implements OnInit {
  @ViewChild('default')
  public textareaObj: TextBoxComponent;
  registerOrgForm: FormGroup;
  loading = false;
  submitted = false;

  public stateData: State[];
  public stateFields: Object = { text: 'statename', value: 'stateid' };
  
  public ctryData: Country[];
  public ctryFields: Object = { text: 'countryname', value: 'countryid' };
  
  constructor(private formBuilder: FormBuilder,
    private utilService: UtilService,
    private router: Router) { }

  ngOnInit(): void {
    this.registerOrgForm = this.formBuilder.group({
      organizationname: ['', Validators.required],
      description: [''],
      addr1: [''],
      addr2: [''],
      city: [''],
      state: [''],
      country: [''],
      zip: ['']
    });

    this.utilService.getCountry().then((res: any) => {
      if(res) {
        this.ctryData = res;
      }
    });
  }

  get f() { return this.registerOrgForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerOrgForm.invalid) {
        return;
    }

    this.loading = true;

    let inputOrg = new Organization();
    inputOrg.orgname = this.f.meetname.value;
    inputOrg.description = this.f.description.value;
    inputOrg.addr1 = this.f.addr1.value;
    inputOrg.addr2 = this.f.addr2.value;
    inputOrg.city = this.f.city.value;
    inputOrg.statecode = this.f.state.value;
    inputOrg.countrycode = this.f.country.value;
    inputOrg.zip = this.f.zip.value;

    this.utilService.registerOrganization(inputOrg).then(res => {
      if(res) {
        this.router.navigate([Constants.PG_REGISTER_MEET]);
      }
    });
  }

  public createHandler(e): void {
    this.textareaObj.addAttributes({rows: '1'});
    this.textareaObj.element.style.height = "auto";
    this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }

  public inputHandler(e): void {
    this.textareaObj.element.style.height = "auto";
    this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }

  crtyChangeEvent(e : any) {
    this.utilService.getState(e.value).then((res: any) => {
      if(res) {
        this.stateData = res;
      } else {
        this.stateData = [];
      }
    });
  }
}
