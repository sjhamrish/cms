import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterorganizationComponent } from './registerorganization.component';

describe('RegisterorganizationComponent', () => {
  let component: RegisterorganizationComponent;
  let fixture: ComponentFixture<RegisterorganizationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterorganizationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterorganizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
