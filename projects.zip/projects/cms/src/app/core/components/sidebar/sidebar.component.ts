import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuItemModel, SidebarComponent as SidebarComponentD } from '@syncfusion/ej2-angular-navigations';
import { Subscription } from 'rxjs';
import { MasterService } from '../../services/master.service';
import { MenuService } from '../../services/menu.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  @ViewChild('sidebarMenuInstance')
  public sidebarMenuInstance: SidebarComponentD;
  public width: string = '500px';
  public mediaQuery: string = ('(min-width: 600px)');
  public target: string = '.main-content';
  public dockSize: string = '50px';
  public enableDock: boolean = true;

  subscription: Subscription;

  constructor(public masterService: MasterService,
    public menuService: MenuService) { }

  @ViewChild('sidebar') sidebar: SidebarComponent;
  public onCreated(args: any) {
      //  this.sidebar.element.style.visibility = '';
  }
  
  public menuItems: MenuItemModel[];

  ngOnInit(): void {
    this.menuItems =this.masterService.leftMenu;
    this.subscription = this.menuService.observeMenu().subscribe(() => {
      this.menuItems =this.masterService.leftMenu;  
    });
    
  }

  newTabClick(): void {
    let URL = location.href.replace(location.search,'');
    document.getElementById('newTab').setAttribute('href', URL.split('#')[0] + 'sidebar/sidebar-menu');
  }
  
  openClick() {
    this.sidebarMenuInstance.toggle();
  }
}
