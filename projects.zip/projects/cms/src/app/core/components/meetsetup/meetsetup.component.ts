import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DropDownList, DropDownListComponent } from '@syncfusion/ej2-angular-dropdowns';
import { DataStateChangeEventArgs, EditSettingsModel, GridComponent, IEditCell, ToolbarItems } from '@syncfusion/ej2-angular-grids';
import { TextBox, TextBoxComponent } from '@syncfusion/ej2-angular-inputs';
import { ClickEventArgs, DataSourceChangedEventArgs } from '@syncfusion/ej2-angular-navigations';
import { Eventplayerscore } from '../../models/eventplayerscore';
import { Events } from '../../models/events';
import { Meet } from '../../models/meet';
import { Player } from '../../models/player';
import { User } from '../../models/user';
import { MeetService } from '../../services/meet.service';
import { Constants } from '../../utilities/constants';

import { MouseEventArgs } from '@syncfusion/ej2-base';
import { Query, DataManager } from '@syncfusion/ej2-data';
import { Observable } from 'rxjs';
import { Meetuser } from '../../models/meetuser';

@Component({
  selector: 'app-meetsetup',
  templateUrl: './meetsetup.component.html',
  styleUrls: ['./meetsetup.component.scss']
})
export class MeetsetupComponent implements OnInit {
  textareaObj: TextBoxComponent;
  
  @ViewChild('grid') 
  public grid: GridComponent;

  // public data: Observable<DataStateChangeEventArgs>;
  // public state: DataStateChangeEventArgs;
  // public playerParams: IEditCell;
  // public playerIdParams: IEditCell;

  eventForm: FormGroup;
  form: FormGroup;
  enrollForm: FormGroup;
  loading = false;
  enrollLoading = false;
  submitted = false;
  
  meetId: string;
  meetEventId: string;
  value: number = 0;
  
  meetInfo: Meet;
  eventInfo: Events;

  eventplayers: Eventplayerscore[];

  evntData: Events[];
  evntFields: Object = { text: 'eventname', value: 'meeteventid' };

  refData: Meetuser[];
  refFields: Object = { text: 'username', value: 'meetuserid' };

  meetData: Meet[];
  meetFields: Object = {text:'meetName',value:'meetId' };

  playerData: Player[];
  playerFields: Object = {text:'playername',value:'playerid' };
  
  // public playerElem : HTMLElement;
  // public playerObj : DropDownList;

  // public playerIdElem : HTMLElement;
  // public playerIdObj : TextBox;
  
  editSettings: EditSettingsModel;
  toolbar: ToolbarItems[] | object;
  
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private meetService: MeetService,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.eventForm = this.formBuilder.group({
      event: ['', Validators.required],
      reportingtime: ['', Validators.required],
      lanes: ['', Validators.required],
      referee: ['', Validators.required]
    });

    this.form = this.formBuilder.group({
      meet: ['']
    });

    this.enrollForm = this.formBuilder.group({
      player: ['', Validators.required],
      lane: [''],
      reportedTime: ['']
    });

    this.meetId = this.route.snapshot.paramMap.get('meetid');
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Batch' };
    this.toolbar =  ['Delete', 'Update', 'Cancel'];
    this.meetService.getMeets().then((res:any)=>{
      this.meetData = res;
    });
    
    this.value = Number(this.meetId);
    this.populateDropDown();

    // this.playerIdParams = {
    //   create:()=>{ 
    //     this.playerIdElem = document.createElement('input'); 
    //     return this.playerIdElem; 
    //   }, 
    //   destroy:()=>{ 
    //       this.playerIdObj.destroy(); 
    //   }, 
    //   read:()=>{ 
    //       return this.playerIdObj.value; 
    //   }, 
    //   write:()=>{ 
    //     this.playerIdObj = new TextBox({
    //       placeholder: 'Player Id',
    //       floatLabelType: 'Auto'
    //     });
    //     this.playerIdObj.appendTo(this.playerIdElem);
    //   }
    // };

    // this.playerParams = {
    //   create:()=>{ 
    //     this.playerElem = document.createElement('input'); 
    //     return this.playerElem; 
    //   }, 
    //   destroy:()=>{ 
    //       this.playerObj.destroy(); 
    //   }, 
    //   read:()=>{ 
    //       return this.playerObj.text; 
    //   }, 
    //   write:(args: { rowData: any, column: any })=>{ 
    //     if(!this.playerIdObj) {
    //       this.playerIdObj = new TextBox({
    //         placeholder: 'Player Id',
    //         floatLabelType: 'Auto'
    //       });
    //       this.playerIdObj.appendTo(this.playerIdElem);
    //     }

    //     this.playerObj = new DropDownList({
    //       dataSource: this.playerData,
    //       fields: { value: 'playerid', text: 'playername' },
    //       change: (e: any) => {
    //         this.playerIdObj.value = this.playerObj.value.toString();
    //         // let data1 = this.playerObj.value.toString();
    //         // args.rowData.playerid = data1;
    //         // this.grid.updateRowValue(this.index, args.rowData);
    //         // this.grid.updateRowValue(refresh(); 
    //       }
    //     });

    //     this.playerObj.appendTo(this.playerElem);
    //   }
    // };

    
  }

  populateDropDown() {
    if(this.meetId) {
      this.meetService.GetMeetInfo(this.meetId).then((res: any) => {
        if (res) {
          this.meetInfo = res;
        }
      })
  
      this.meetService.getAllEventsInMeet(this.meetId).then((res: any) => {
        if(res) {
          this.evntData = res;
        }
      })
  
      this.meetService.getMeetuserList(this.meetId).then((res: any) => {
        if(res) {
          this.refData = res;
        }
      })

      this.meetService.getPlayerList().then((res: any) => {
        if(res) {
          this.playerData = res;
        }
      })
    }
  }

  onUpdateClick() {
    this.router.navigate([Constants.PG_REGISTER_MEET, {meetid: this.meetId}]);
  }

  onAddClick() {
    this.router.navigate([Constants.PG_MEET_USER, {meetid: this.meetId}]);
  }

  onScoreClick() {
    if (this.meetEventId) {
      this.router.navigate([Constants.PG_MEET_SCORE, {meetid: this.meetId, meeteventid: this.meetEventId}]);
    } else {
      // TODO Alert
    }
    
  }

  public createHandler(e): void {
    // this.textareaObj.addAttributes({rows: '1'});
    // this.textareaObj.element.style.height = "auto";
    // this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }

  public inputHandler(e): void {
    // this.textareaObj.element.style.height = "auto";
    // this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }

  get f() { return this.eventForm.controls; }
  get m() { return this.form.controls; }
  get e() { return this.enrollForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.eventForm.invalid) {
        return;
    }

    let inputEvent = new Events();
    inputEvent.meeteventid = this.f.event.value;
    inputEvent.reportingtime = this.f.reportingtime.value;
    inputEvent.lanes = this.f.lanes.value;
    inputEvent.referree = new Player();
    inputEvent.referree.playerid = this.f.referee.value;

    this.loading = true;
    this.meetService.updateMeetEvent(inputEvent).then((res: any) => {
      if(res) {
        this.loading = false;
      }
    }).finally(() => {
      this.loading = false;
    });
  }

  onEnrollSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.enrollForm.invalid && this.meetEventId) {
        return;
    }

    this.enrollLoading = true;
    
    this.meetService.EnrollPlayer(this.meetEventId, this.e.player.value, 
      this.e.lane.value === '' ? '0' : this.e.lane.value, 
      this.e.reportedTime.value === '' ? '0' : this.e.reportedTime.value, '0').then(res => {
      this.enrollLoading = false;
      this.meetService.GetEventPlayers(this.meetEventId).then((res: any) => {
        if(res) {
          this.eventplayers = res;
        } else {
          this.eventplayers = [];
        }
      });
    }).finally(() => {
      this.enrollLoading = false;
    });
  }

  eventChangeEvent(e : any) {
    this.meetEventId = e.value;
    this.meetService.GetEventById(e.value).then((res: any) => {
      if(res) {
        this.eventInfo = res;
      }
    });

    this.meetService.GetEventPlayers(e.value).then((res: any) => {
      if(res) {
        this.eventplayers = res;
      } else {
        this.eventplayers = [];
      }
    });
  }

  meetChangeEvent(e : any) {
    this.meetId = e.value;
    this.populateDropDown();
  }

  public beforeBatchSave(e: any): void {
    e.cancel = true;         
    let data = { 
        action: 'batch', Changed: e.batchChanges.changedRecords, Deleted: e.batchChanges.deletedRecords 
    }
    
    let regId: string = '';
    let lanes: string = '';
    let reportingTimes: string = '';
    let scoreIds: string = '';
    let scores: string = '';

    data.Changed.forEach(element => {
      if(regId === '') {
        regId = element.registrationid;
      } else {
        regId += ',' + element.registrationid;
      }

      if(lanes === '') {
        lanes = element.lane;
      } else {
        lanes += ',' + element.lane;
      }

      if(reportingTimes === '') {
        reportingTimes = element.reportedtime === '' ? '0' : element.reportedtime;
      } else {
        reportingTimes += ',' + (element.reportedtime === '' ? '0' : element.reportedtime);
      }

      if(scoreIds === '') {
        scoreIds = element.scoreid;
      } else {
        scoreIds += ',' + element.scoreid;
      }

      if(scores === '') {
        scores = element.score;
      } else {
        scores += ',' + element.score;
      }
    });

    this.meetService.UpdateScore(regId, lanes, reportingTimes, scoreIds, scores).then(res => {
      this.meetService.GetEventPlayers(this.meetEventId).then((res: any) => {
        if(res) {
          this.eventplayers = res;
          this.grid.refresh();
        } else {
          this.eventplayers = [];
        }
      });
    });
  }

  clickHandler(args: ClickEventArgs): void {
    // toolbar click event
  }

  load(args){
    this.grid.element.addEventListener('mousedown', (e: MouseEventArgs) => {
      if ((e.target as HTMLElement).classList.contains("e-rowcell")) {
        let index: number = parseInt((e.target as HTMLElement).getAttribute("Index"));
        let colindex: number = parseInt((e.target as HTMLElement).getAttribute("aria-colindex"));
        let field: string = this.grid.getColumns()[colindex].field;
        this.grid.editModule.editCell(index, field);
      };
    });
  }
}
