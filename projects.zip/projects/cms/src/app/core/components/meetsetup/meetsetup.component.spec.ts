import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeetsetupComponent } from './meetsetup.component';

describe('MeetsetupComponent', () => {
  let component: MeetsetupComponent;
  let fixture: ComponentFixture<MeetsetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeetsetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeetsetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
