import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Meet } from '../../models/meet';
import { MeetService } from '../../services/meet.service';

@Component({
  selector: 'app-meetdashboard',
  templateUrl: './meetdashboard.component.html',
  styleUrls: ['./meetdashboard.component.scss']
})
export class MeetdashboardComponent implements OnInit {
  public data: Meet[] = [];

  constructor(private meetService: MeetService,
    private router: Router) { }

  ngOnInit(): void {
    this.meetService.getMeets().then((res: any) => {
      if(res) {
        this.data = res;
      }
    });
  }

  onClick(meetUrl, id) {
    this.router.navigate([meetUrl, {meetid: id}]);
  }

}
