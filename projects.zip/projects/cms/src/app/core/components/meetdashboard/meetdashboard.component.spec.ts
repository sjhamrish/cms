import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeetdashboardComponent } from './meetdashboard.component';

describe('MeetdashboardComponent', () => {
  let component: MeetdashboardComponent;
  let fixture: ComponentFixture<MeetdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeetdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeetdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
