import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DropDownListComponent } from '@syncfusion/ej2-angular-dropdowns';
import { TextBoxComponent } from '@syncfusion/ej2-angular-inputs';
import { Events } from '../../models/events';
import { Player } from '../../models/player';
import { MeetService } from '../../services/meet.service';

@Component({
  selector: 'app-registerevent',
  templateUrl: './registerevent.component.html',
  styleUrls: ['./registerevent.component.scss']
})
export class RegistereventComponent implements OnInit {
  @ViewChild('default')
  public textareaObj: TextBoxComponent;

  @ViewChild('player')
  public playerListObject: DropDownListComponent;
  
  registerEventForm: FormGroup;
  playerForm: FormGroup;
  playerLoading = false;
  EnrollLoading = false;
  submitted = false;
  editPlayer = false;

  enableEnroll = true;

  evntData: Events[];
  public evntFields: Object = { text: 'eventname', value: 'meeteventid' };

  playerData: Player[];
  public playerFields: Object = { text: 'playername', value: 'playerid' };

  playerInfo: Player;
  eventInfo: Events;
  meetId: string;

  constructor(private formBuilder: FormBuilder,
    private meetService: MeetService,
    private route: ActivatedRoute,
    public datepipe: DatePipe) { }

  ngOnInit(): void {
    this.registerEventForm = this.formBuilder.group({
      event: ['', Validators.required],
      player: ['', Validators.required]
    });

    this.playerForm = this.formBuilder.group({
      playerid: [''],
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      dob: ['', Validators.required],
      verificationid: [''],
      isverified: ['']
    });

    this.meetId = this.route.snapshot.paramMap.get('meetid');

    this.meetService.getPlayerInfo().then((res: any) => {
      if (res) {
        this.playerInfo = res;

        this.p.playerid.setValue(this.playerInfo.playerid);
        this.p.firstname.setValue(this.playerInfo.firstname);
        this.p.lastname.setValue(this.playerInfo.lastname);
        this.p.dob.setValue(this.playerInfo.dob);
        this.p.verificationid.setValue(this.playerInfo.verificationid);
        this.p.isverified.setValue(this.playerInfo.isverified);
        
        this.editPlayer = false;
      }
    })

    this.meetService.getAllEventsInMeet(this.meetId).then((res: any) => {
      if(res) {
        this.evntData = res;
      }
    })

    this.meetService.getPlayerList().then((res: any) => {
      if(res) {
        this.playerData = res;
      }
    })
  }

  get f() { return this.registerEventForm.controls; }
  get p() { return this.playerForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.playerForm.invalid) {
        return;
    }

    this.EnrollLoading = true;
    
    this.meetService.EnrollPlayer(this.f.event.value, this.f.player.value, '0', '0', '0').then(res => {
      this.EnrollLoading = false;
    }).finally(() => {
      this.EnrollLoading = false;
    });
  }

  onPlayerSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.playerForm.invalid) {
        return;
    }

    this.playerLoading = true;
    let inputPlayer = new Player();
    inputPlayer.playerid = this.p.playerid.value ? this.p.playerid.value : 0;
    inputPlayer.firstname = this.p.firstname.value;
    inputPlayer.lastname = this.p.lastname.value;
    inputPlayer.dob = this.datepipe.transform(new Date(this.p.dob.value), 'yyyy-MM-dd');
    inputPlayer.verificationid = this.p.verificationid.value;
    inputPlayer.isverified = this.p.isverified.value;
    inputPlayer.playertypeid = 1;
    
    this.meetService.registerPlayer(inputPlayer).then(() => {
      this.playerLoading = false;
      this.meetService.getPlayerInfo().then((res: any) => {
        if (res) {
          this.playerInfo = res;
        }
      })
    }).finally(() => {
      this.playerLoading = false;
    });
  }

  public createHandler(e): void {
    this.textareaObj.addAttributes({rows: '1'});
    this.textareaObj.element.style.height = "auto";
    this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }

  public inputHandler(e): void {
    this.textareaObj.element.style.height = "auto";
    this.textareaObj.element.style.height = (this.textareaObj.element.scrollHeight)+"px";
  }

  onRegisterClick() {
    this.editPlayer = true;
  }

  onCancelClick() {
    this.editPlayer = false;
  }

  eventChangeEvent(e : any) {
    this.meetService.GetEventById(e.value).then((res: any) => {
      if(res) {
        this.eventInfo = res;

        this.meetService.IsPlayerEnrolled(e.value, this.p.playerid.value).then((res: any) => {
          if(res) {
            if(res === 'True') {
              this.playerListObject.value = this.p.playerid.value;
              this.enableEnroll = true;
            } else {
              this.enableEnroll = false;
            }
          }
        });
      }
    });
  }
}
