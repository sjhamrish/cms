import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterplayerComponent } from './registerplayer.component';

describe('RegisterplayerComponent', () => {
  let component: RegisterplayerComponent;
  let fixture: ComponentFixture<RegisterplayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterplayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterplayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
