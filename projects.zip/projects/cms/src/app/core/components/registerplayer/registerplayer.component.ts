import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerplayer',
  templateUrl: './registerplayer.component.html',
  styleUrls: ['./registerplayer.component.scss']
})
export class RegisterplayerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
