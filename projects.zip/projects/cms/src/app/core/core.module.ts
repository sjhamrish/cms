import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { SharedModule } from './../shared/shared.module';

import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { MenuModule, SidebarModule } from '@syncfusion/ej2-angular-navigations';
import { AccounthomeComponent } from './components/accounthome/accounthome.component';
import { RegistereventComponent } from './components/registerevent/registerevent.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { FormControlsModule } from '../../../../form-controls/src/public-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextBoxModule } from '@syncfusion/ej2-angular-inputs';
import { DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';
import { CheckBoxModule, RadioButtonModule } from '@syncfusion/ej2-angular-buttons';
import { DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { RegisterorganizationComponent } from './components/registerorganization/registerorganization.component';
import { MeetdashboardComponent } from './components/meetdashboard/meetdashboard.component';
import { FilterService, GridModule, GroupService, PageService, SortService } from '@syncfusion/ej2-angular-grids';
import { MeeteventsComponent } from './components/meetevents/meetevents.component';
import { MeetscoringComponent } from './components/meetscoring/meetscoring.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ReportComponent } from './components/report/report.component';
import { MeetsetupComponent } from './components/meetsetup/meetsetup.component';
import { RegistermeetComponent } from './components/registermeet/registermeet.component';
import { RegisterplayerComponent } from './components/registerplayer/registerplayer.component';
import { MeetuserComponent } from './components/meetuser/meetuser.component';

@NgModule({
  declarations: [HeaderComponent, FooterComponent, HomeComponent, AccounthomeComponent, RegistereventComponent, SidebarComponent, RegisterorganizationComponent, MeetdashboardComponent, MeeteventsComponent, MeetscoringComponent, DashboardComponent, ReportComponent, MeetsetupComponent, RegistermeetComponent, RegisterplayerComponent, MeetuserComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    SharedModule,
    RouterModule,
    MenuModule,
    SidebarModule,
    FormsModule,
    ReactiveFormsModule,
    FormControlsModule,
    TextBoxModule,
    DropDownListModule,
    CheckBoxModule,
    DatePickerModule,
    RadioButtonModule,
    GridModule
  ],
  exports: [HeaderComponent, FooterComponent, HomeComponent],
  providers: [PageService,
    SortService,
    FilterService,
    GroupService]
})
export class CoreModule { }
