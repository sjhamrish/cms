import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './features/login/components/register/register.component';
import { LoginComponent } from './features/login/components/login/login.component';
import { HomeComponent } from './core/components/home/home.component';
import { AccounthomeComponent } from './core/components/accounthome/accounthome.component';
import { AuthGuard } from './core/guard/auth.guard';
import { LogoutComponent } from './features/logout/logout.component';
import { RegistereventComponent } from './core/components/registerevent/registerevent.component';
import { MeetdashboardComponent } from './core/components/meetdashboard/meetdashboard.component';
import { MeeteventsComponent } from './core/components/meetevents/meetevents.component';
import { DashboardComponent } from './core/components/dashboard/dashboard.component';
import { ReportComponent } from './core/components/report/report.component';
import { MeetsetupComponent } from './core/components/meetsetup/meetsetup.component';
import { MeetscoringComponent } from './core/components/meetscoring/meetscoring.component';
import { RegistermeetComponent } from './core/components/registermeet/registermeet.component';
import { RegisterorganizationComponent } from './core/components/registerorganization/registerorganization.component';
import { MeetuserComponent } from './core/components/meetuser/meetuser.component';
const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'accounthome', component: AccounthomeComponent},
  {path: 'registerevent', component: RegistereventComponent},
  {path: 'registermeet', component: RegistermeetComponent},
  {path: 'registerorganization', component: RegisterorganizationComponent},
  {path: 'dashboard', component: DashboardComponent},
  {path: 'reports', component: ReportComponent},
  {path: 'meetdashboard', component: MeetdashboardComponent},
  {path: 'meetsetup', component: MeetsetupComponent},
  {path: 'scoring', component: MeetscoringComponent},
  {path: 'meetevents', component: MeeteventsComponent},
  {path: 'meetuser', component: MeetuserComponent},
  {path: '**', redirectTo: 'home' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
